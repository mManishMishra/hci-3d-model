import os
import sys
import time
import json
import argparse
import math
import re
import faulthandler
import importlib.util
import ifcopenshell
import ifcopenshell.guid
from google import genai
from google.genai import types
from google.genai.errors import APIError, ServerError, ClientError
from pydantic import BaseModel, Field
from typing import List, Optional

faulthandler.enable()

# =====================================================================
# 1. COMPREHENSIVE DATA MODELS
# =====================================================================
class OpeningComponent(BaseModel):
    id: str
    type: str = Field(description="door, window, or arch opening")
    location_pt: List[float] = Field(description="[x, y] center of the opening")
    width: float = 0.90
    height: float = 2.10
    parent_wall_id: str
    unit: str = "m"

class InteriorComponent(BaseModel):
    id: str
    category: str = Field(description="furnishing, sanitary, or appliance")
    location_pt: List[float]
    dimensions: List[float] = Field(default=[0.8, 0.8, 0.5], description="[w, d, h]")
    unit: str = "m"

class WallData(BaseModel):
    wall_id: str
    start_pt: List[float] = Field(description="Centerline start point")
    end_pt: List[float] = Field(description="Centerline end point")
    thickness: float = 0.23
    height: float = 3.0
    unit: str = "m"

class BuildingAnalysis(BaseModel):
    building_name: str = "1 BHK Detailed Plan"
    walls: List[WallData]
    openings: List[OpeningComponent] = Field(default_factory=list)
    interiors: List[InteriorComponent] = Field(default_factory=list)


def find_ifc_properties_files(search_root: str = None) -> List[str]:
    """Recursively search for all ifc_properties.py files under the workspace root."""
    root = os.path.abspath(search_root or os.path.dirname(__file__))
    matches = []
    for dirpath, dirnames, filenames in os.walk(root):
        if "ifc_properties.py" in filenames:
            matches.append(os.path.join(dirpath, "ifc_properties.py"))
    return matches


def load_ifc_properties_module(path: str):
    spec = importlib.util.spec_from_file_location("ifc_properties", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _to_meters(value: float, unit: str) -> float:
    if unit == "mm":
        return value / 1000.0
    if unit == "cm":
        return value / 100.0
    if unit == "in":
        return value * 0.0254
    return value


def _to_square_meters(value: float, unit: str) -> float:
    if unit == "mm2":
        return value / 1_000_000.0
    if unit == "cm2":
        return value / 10_000.0
    if unit == "in2":
        return value * 0.00064516
    if unit == "m2":
        return value
    return value


def _convert_to_meters(value: float, unit: str) -> float:
    if value is None:
        return 0.0
    return _to_meters(value, unit or "m")


def _normalize_point(point: List[float], unit: str) -> List[float]:
    return [_convert_to_meters(coord, unit) for coord in point]


def _make_ifc_value(model, value, prop_name: str = None, unit: str = None):
    if isinstance(value, bool):
        return model.create_entity("IfcBoolean", value)

    area_pattern = re.compile(r"(area|floorarea|netfloorarea|grossfloorarea|surfacearea)", re.I)
    length_pattern = re.compile(r"(height|width|length|thickness|depth|cill|installationheight|thresholdheight|riserheight|treadlength|distance|offset|rise|run|diameter|radius)", re.I)
    unit_str = (unit or "").strip().lower()

    if isinstance(value, int) and not isinstance(value, bool):
        if unit_str in {"m", "mm", "cm", "in"} or (prop_name and length_pattern.search(prop_name)):
            converted = float(value)
            if unit_str:
                converted = _to_meters(converted, unit_str)
            return model.create_entity("IfcLengthMeasure", converted)
        if unit_str in {"m2", "mm2", "cm2", "in2"} or (prop_name and area_pattern.search(prop_name)):
            converted = float(value)
            if unit_str:
                converted = _to_square_meters(converted, unit_str)
            return model.create_entity("IfcAreaMeasure", converted)
        return model.create_entity("IfcInteger", value)

    if isinstance(value, float):
        if unit_str in {"m", "mm", "cm", "in"} or (prop_name and length_pattern.search(prop_name)):
            converted = value
            if unit_str:
                converted = _to_meters(converted, unit_str)
            return model.create_entity("IfcLengthMeasure", converted)
        if unit_str in {"m2", "mm2", "cm2", "in2"} or (prop_name and area_pattern.search(prop_name)):
            converted = value
            if unit_str:
                converted = _to_square_meters(converted, unit_str)
            return model.create_entity("IfcAreaMeasure", converted)
        return model.create_entity("IfcReal", value)

    if isinstance(value, str):
        return model.create_entity("IfcLabel", value)
    return None


def create_ifc_property_set(model, owner_history, element, pset_name: str, properties: dict, property_metadata: dict = None):
    if not properties:
        return None

    property_metadata = property_metadata or {}
    pset_props = []
    for prop_name, prop_value in properties.items():
        if prop_value is None:
            continue
        prop_meta = property_metadata.get(prop_name, {})
        nominal_value = _make_ifc_value(model, prop_value, prop_name=prop_name, unit=prop_meta.get("unit"))
        if nominal_value is None:
            continue

        pset_props.append(
            model.create_entity(
                "IfcPropertySingleValue",
                prop_name,
                None,
                nominal_value,
            )
        )

    if not pset_props:
        return None

    pset = model.create_entity(
        "IfcPropertySet",
        GlobalId=ifcopenshell.guid.new(),
        OwnerHistory=owner_history,
        Name=pset_name,
        HasProperties=pset_props,
    )
    # Create relationship between element and property set
    model.create_entity(
        "IfcRelDefinesByProperties",
        ifcopenshell.guid.new(),  # GlobalId as positional
        owner_history,  # OwnerHistory as positional
        None,  # Name
        None,  # Description
        [element],  # RelatedObjects
        pset,  # RelatingPropertyDefinition
    )
    return pset


def create_ifc_quantity_set(model, owner_history, element, qset_name: str, quantities: dict):
    if not quantities:
        return None

    qset_props = []
    for qty_name, qty_value in quantities.items():
        if qty_value is None:
            continue
        if isinstance(qty_value, (int, float)):
            # IfcQuantityLength has only 4 attributes in IFC4:
            # Name, Description, Unit, LengthValue
            qty = model.create_entity(
                "IfcQuantityLength",
                Name=qty_name,
                Description=None,
                Unit=None,
                LengthValue=float(qty_value),
            )
        else:
            continue
        qset_props.append(qty)

    if not qset_props:
        return None

    qset = model.create_entity(
        "IfcElementQuantity",
        GlobalId=ifcopenshell.guid.new(),
        OwnerHistory=owner_history,
        Name=qset_name,
        Quantities=qset_props,
    )
    # Create relationship between element and quantity set
    model.create_entity(
        "IfcRelDefinesByProperties",
        ifcopenshell.guid.new(),  # GlobalId as positional
        owner_history,  # OwnerHistory as positional
        None,  # Name
        None,  # Description
        [element],  # RelatedObjects
        qset,  # RelatingPropertyDefinition
    )
    return qset


def normalize_opening_type(op_type: str) -> str:
    """Normalize opening type string to canonical 'door' or 'window'."""
    if not op_type:
        return "door"
    normalized = op_type.strip().lower()
    if "window" in normalized:
        return "window"
    if "arch" in normalized or "portal" in normalized:
        return "door"
    if "door" in normalized:
        return "door"
    return "door"


def create_archicad_name_pset(model, owner_history, element, name: str):
    """Create ArchiCAD-compatible name property."""
    pset = model.create_entity(
        "IfcPropertySet",
        GlobalId=ifcopenshell.guid.new(),
        OwnerHistory=owner_history,
        Name="ArchiCADPName",
        HasProperties=[
            model.create_entity(
                "IfcPropertySingleValue",
                "Name",
                None,
                model.create_entity("IfcLabel", name),
            )
        ],
    )
    model.create_entity(
        "IfcRelDefinesByProperties",
        ifcopenshell.guid.new(),  # GlobalId
        owner_history,  # OwnerHistory
        None,  # Name
        None,  # Description
        [element],  # RelatedObjects
        pset,  # RelatingPropertyDefinition
    )


def create_archicad_properties_pset(model, owner_history, element, element_id: str):
    """Create ArchiCAD-compatible properties."""
    pset = model.create_entity(
        "IfcPropertySet",
        GlobalId=ifcopenshell.guid.new(),
        OwnerHistory=owner_history,
        Name="ArchiCADProperties",
        HasProperties=[
            model.create_entity(
                "IfcPropertySingleValue",
                "GuidValue",
                None,
                model.create_entity("IfcLabel", str(ifcopenshell.guid.new())),
            )
        ],
    )
    model.create_entity(
        "IfcRelDefinesByProperties",
        ifcopenshell.guid.new(),  # GlobalId
        owner_history,  # OwnerHistory
        None,  # Name
        None,  # Description
        [element],  # RelatedObjects
        pset,  # RelatingPropertyDefinition
    )


def _log_property_attachment(element, pset_name: str, prop_values: dict):
    """Debug log for property attachment."""
    print(f"  [DEBUG] Attached {pset_name}: {list(prop_values.keys())}")


def assign_default_ifc_properties(model, owner_history, element, entity_type: str = None, props_module=None, custom_overrides: dict = None, debug: bool = False):
    """Assign default IFC properties from schema to element, with optional custom overrides."""
    if not props_module:
        return
    
    entity_type = entity_type or element.is_a()
    defaults = {}
    metadata = {}

    if hasattr(props_module, "IFC_SCHEMA"):
        schema = props_module.IFC_SCHEMA
        for cls_name in [entity_type, entity_type.replace("Ifc", "")]:
            if cls_name in schema:
                schema_def = schema[cls_name]
                for pset_name, props in schema_def.get("psets", {}).items():
                    pset_defaults = {}
                    pset_metadata = {}
                    for prop_name, prop_meta in props.items():
                        if "default" in prop_meta:
                            prop_value = prop_meta["default"]
                            if prop_value is None:
                                continue
                            pset_defaults[prop_name] = prop_value
                            pset_metadata[prop_name] = prop_meta
                    if pset_defaults:
                        defaults[pset_name] = pset_defaults
                        metadata[pset_name] = pset_metadata
    elif hasattr(props_module, "get_default_pset"):
        defaults = props_module.get_default_pset(entity_type)

    # Merge custom overrides into property sets
    if custom_overrides:
        for pset_name, props in custom_overrides.items():
            if pset_name in defaults:
                defaults[pset_name].update(props)
            else:
                defaults[pset_name] = props

    if debug and not defaults:
        print(f"[IFC-DEBUG] No default schema properties found for entity_type={entity_type}")

    for pset_name, prop_values in defaults.items():
        pset = create_ifc_property_set(model, owner_history, element, pset_name, prop_values, property_metadata=metadata.get(pset_name, {}))
        if debug and pset is not None:
            _log_property_attachment(element, pset_name, prop_values)


# =====================================================================
# 2. API LOGIC (Centerline & Detail Extraction)
# =====================================================================
def analyze_floor_plan_detailed(image_path: str) -> BuildingAnalysis:
    """
    Analyze a floor plan image using Gemini API.
    
    Returns: BuildingAnalysis object with walls, openings, and interior elements.
    Raises: SystemExit on API or file errors.
    """
    client = genai.Client()
    if not os.environ.get("GEMINI_API_KEY"):
        sys.exit("[!] Error: GEMINI_API_KEY is not set.")

    # Determine mime type from file extension
    ext = os.path.splitext(image_path)[1].lower()
    mime_map = {
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.png': 'image/png',
        '.svg': 'image/jpeg'
    }
    mime_type = mime_map.get(ext, 'application/octet-stream')
    
    with open(image_path, 'rb') as f:
        image_bytes = f.read()
        image_part = types.Part.from_bytes(data=image_bytes, mime_type=mime_type)
    
    prompt = (
        "Analyze the floor plan and extract detailed architectural data.\n\n"
        "1. Extract ALL wall segments using CENTERLINE coordinates to ensure corners meet perfectly.\n"
        "   - Pay close attention to wall thickness. Estimate the physical wall thickness based on "
        "the visual proportions in the drawing (e.g., thicker structural exterior walls vs. thinner interior partition walls).\n\n"
        "2. Identify all Doors and Windows as 'openings' and specify their host wall.\n"
        "   - Treat arched doorways, arched openings, and portal-style openings as doors.\n"
        "   - Estimate the exact width and height of each opening based on its proportion relative to the "
        "surrounding walls and spaces in the 2D drawing (e.g., a wide window or large double door vs. a small toilet door).\n\n"
        "3. Identify all interior elements including furniture (e.g., Sofa, Bed, Table, Wardrobe), sanitary components "
        "(e.g., Toilet, Sink, Bathtub), and appliances (e.g., Fridge, Stove, Washing Machine).\n"
        "   - For each element, estimate its actual length, breadth (depth), and height [width, depth, height] in meters "
        "strictly based on the physical size and proportion shown in the 2D drawing relative to the floor plan's space.\n"
        "   - Ensure that larger items (like a multi-seat sofa or a king-sized bed) and smaller items (like a single chair or small toilet sink) "
        "are given realistic, proportion-accurate dimensions representing their size as drawn.\n\n"
        "Return the results in structured JSON according to the schema."
    )
    
    print("[API] Running Detailed Visual Extraction...")
    
    try:
        response = client.models.generate_content(
            model='gemini-2.5-flash', 
            contents=[image_part, prompt],
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
                response_schema=BuildingAnalysis,
                temperature=0.1
            ),
        )
    except (APIError, ServerError, ClientError) as e:
        print(f"[API-ERROR] GenAI API failed: {e}")
        sys.exit(2)
    except Exception as e:
        print(f"[API-ERROR] Unexpected error during visual extraction: {e}")
        print("Hint: check GEMINI_API_KEY, network access, and that the image MIME type matches the file.")
        sys.exit(3)

    # response.parsed should contain the BuildingAnalysis instance
    return response.parsed

# =====================================================================
# 3. BIM COMPILER (With Unpacking Fix)
# =====================================================================
def build_detailed_ifc(data: BuildingAnalysis, output_filepath: str, props_module=None, debug: bool = False):
    print(f"Compiling High-Detail BIM...{' [DEBUG]' if debug else ''}")
    model = ifcopenshell.file(schema="IFC4")
    
    # --- Infrastructure Setup ---
    person = model.create_entity("IfcPerson", Identification="Sushil", FamilyName="Dev")
    org = model.create_entity("IfcOrganization", Name="Entrevista Media")
    p_and_o = model.create_entity("IfcPersonAndOrganization", ThePerson=person, TheOrganization=org)
    app = model.create_entity("IfcApplication", ApplicationDeveloper=org, Version="1.0", ApplicationFullName="OonexBIM")
    owner_h = model.create_entity("IfcOwnerHistory", OwningUser=p_and_o, OwningApplication=app, ChangeAction="ADDED", CreationDate=int(time.time()))
    
    unit_l = model.create_entity("IfcSIUnit", UnitType="LENGTHUNIT", Name="METRE")
    units = model.create_entity("IfcUnitAssignment", Units=[unit_l])
    origin = model.create_entity("IfcCartesianPoint", Coordinates=(0.,0.,0.))
    world_pl = model.create_entity("IfcAxis2Placement3D", Location=origin)
    context = model.create_entity("IfcGeometricRepresentationContext", ContextType="Model", CoordinateSpaceDimension=3, Precision=1e-05, WorldCoordinateSystem=world_pl)
    
    project = model.create_entity("IfcProject", GlobalId=ifcopenshell.guid.new(), Name=data.building_name, OwnerHistory=owner_h, RepresentationContexts=[context], UnitsInContext=units)
    site = model.create_entity("IfcSite", GlobalId=ifcopenshell.guid.new(), Name="Site", ObjectPlacement=model.create_entity("IfcLocalPlacement", RelativePlacement=world_pl))
    building = model.create_entity("IfcBuilding", GlobalId=ifcopenshell.guid.new(), Name="Structure", ObjectPlacement=model.create_entity("IfcLocalPlacement", PlacementRelTo=site.ObjectPlacement, RelativePlacement=world_pl))
    stry_pl = model.create_entity("IfcLocalPlacement", PlacementRelTo=building.ObjectPlacement, RelativePlacement=world_pl)
    storey = model.create_entity("IfcBuildingStorey", GlobalId=ifcopenshell.guid.new(), Name="Ground Floor", ObjectPlacement=stry_pl)

    model.create_entity("IfcRelAggregates", GlobalId=ifcopenshell.guid.new(), RelatingObject=project, RelatedObjects=[site])
    model.create_entity("IfcRelAggregates", GlobalId=ifcopenshell.guid.new(), RelatingObject=site, RelatedObjects=[building])
    model.create_entity("IfcRelAggregates", GlobalId=ifcopenshell.guid.new(), RelatingObject=building, RelatedObjects=[storey])

    elements = []

    # --- 1. WALLS (Centerline Alignment) ---
    for wall in data.walls:
        wall_unit = getattr(wall, "unit", "m") or "m"
        start_pt = _normalize_point(wall.start_pt, wall_unit)
        end_pt = _normalize_point(wall.end_pt, wall_unit)
        wall_thickness = _convert_to_meters(wall.thickness, wall_unit)
        wall_height = _convert_to_meters(wall.height, wall_unit)

        dx, dy = end_pt[0] - start_pt[0], end_pt[1] - start_pt[1]
        length = (dx**2 + dy**2)**0.5
        angle = math.atan2(dy, dx)
        
        wall_origin = model.create_entity("IfcCartesianPoint", Coordinates=(start_pt[0], start_pt[1], 0.0))
        wall_ax = model.create_entity("IfcAxis2Placement3D", Location=wall_origin, RefDirection=model.create_entity("IfcDirection", DirectionRatios=(math.cos(angle), math.sin(angle), 0.0)))
        wall_loc = model.create_entity("IfcLocalPlacement", PlacementRelTo=stry_pl, RelativePlacement=wall_ax)
        
        ifc_wall = model.create_entity(
            "IfcWallStandardCase",
            GlobalId=ifcopenshell.guid.new(),
            Name=wall.wall_id,
            ObjectPlacement=wall_loc,
        )
        wall_overrides = {
            "Pset_WallCommon": {
                "Thickness": wall_thickness * 1000.0,  # Thickness in Pset is in mm
                "Height": wall_height,
                "OverallHeight": wall_height,
                "Width": wall_thickness,
                "OverallWidth": wall_thickness
            }
        }
        assign_default_ifc_properties(model, owner_h, ifc_wall, "IfcWall", props_module, custom_overrides=wall_overrides, debug=debug)

        # Center the extrusion on the centerline
        pts = [model.create_entity("IfcCartesianPoint", Coordinates=c) for c in [(0., -wall_thickness/2), (length, -wall_thickness/2), (length, wall_thickness/2), (0., wall_thickness/2), (0., -wall_thickness/2)]]
        profile = model.create_entity("IfcArbitraryClosedProfileDef", ProfileType="AREA", OuterCurve=model.create_entity("IfcPolyline", Points=pts))
        solid = model.create_entity("IfcExtridedAreaSolid" if hasattr(model, "IfcExtridedAreaSolid") else "IfcExtrudedAreaSolid", SweptArea=profile, Position=world_pl, ExtrudedDirection=model.create_entity("IfcDirection", DirectionRatios=(0.,0.,1.)), Depth=wall_height)

        rep = model.create_entity("IfcShapeRepresentation", ContextOfItems=context, RepresentationIdentifier="Body", RepresentationType="SweptSolid", Items=[solid])
        ifc_wall.Representation = model.create_entity("IfcProductDefinitionShape", Representations=[rep])

        wall_quantities = {
            "Length": length,
            "Height": wall_height,
            "Width": wall_thickness,
            "GrossFootprintArea": length * wall_thickness,
            "NetFootprintArea": length * wall_thickness,
            "GrossVolume": length * wall_thickness * wall_height,
            "NetVolume": length * wall_thickness * wall_height,
        }
        create_ifc_quantity_set(model, owner_h, ifc_wall, "BaseQuantities", wall_quantities)

        create_archicad_name_pset(model, owner_h, ifc_wall, wall.wall_id)
        create_archicad_properties_pset(model, owner_h, ifc_wall, wall.wall_id)

        archicad_quantities = {
            "Höhe": wall_height,
            "Dicke": wall_thickness,
            "Wandlänge an der Außenseite": length + wall_thickness,
            "Wandlänge an der Innenseite": max(length - wall_thickness, 0.0),
            "Maximale Höhe der Wand": wall_height,
            "Minimale Höhe der Wand": wall_height,
            "Länge der Wand in der Achse": length,
            "Fläche": length * wall_thickness,
            "Netto-Volumen": length * wall_thickness * wall_height,
        }
        create_ifc_quantity_set(model, owner_h, ifc_wall, "ArchiCADQuantities", archicad_quantities)

        elements.append(ifc_wall)

    # --- 2. OPENINGS ---
    for op in data.openings:
        op_unit = getattr(op, "unit", "m") or "m"
        op_pt = _normalize_point(op.location_pt, op_unit)
        op_width = _convert_to_meters(op.width, op_unit)
        op_height = _convert_to_meters(op.height, op_unit)
        op_loc = model.create_entity("IfcLocalPlacement", PlacementRelTo=stry_pl, RelativePlacement=model.create_entity("IfcAxis2Placement3D", Location=model.create_entity("IfcCartesianPoint", Coordinates=(op_pt[0], op_pt[1], 0.0))))
        opening_type = normalize_opening_type(op.type)
        if opening_type == "window":
            ifc_ent = model.create_entity("IfcWindow", GlobalId=ifcopenshell.guid.new(), Name=op.id, ObjectPlacement=op_loc, OverallHeight=op_height, OverallWidth=op_width)
            pset_key = "Pset_WindowCommon"
        else:
            ifc_ent = model.create_entity("IfcDoor", GlobalId=ifcopenshell.guid.new(), Name=op.id, ObjectPlacement=op_loc, OverallHeight=op_height, OverallWidth=op_width)
            pset_key = "Pset_DoorCommon"
        
        opening_overrides = {
            pset_key: {
                "OverallWidth": op_width,
                "OverallHeight": op_height
            }
        }
        assign_default_ifc_properties(model, owner_h, ifc_ent, ifc_ent.is_a(), props_module, custom_overrides=opening_overrides, debug=debug)
        elements.append(ifc_ent)

    # --- 3. INTERIOR (With Dimension Fix) ---
    for item in data.interiors:
        item_unit = getattr(item, "unit", "m") or "m"
        item_pt = _normalize_point(item.location_pt, item_unit)
        item_loc = model.create_entity("IfcLocalPlacement", PlacementRelTo=stry_pl, RelativePlacement=model.create_entity("IfcAxis2Placement3D", Location=model.create_entity("IfcCartesianPoint", Coordinates=(item_pt[0], item_pt[1], 0.0))))
        
        # SAFE UNPACKING FIX
        dims = [_convert_to_meters(v, item_unit) for v in item.dimensions]
        w = dims[0] if len(dims) > 0 else 0.8
        d = dims[1] if len(dims) > 1 else 0.8
        # Standardize height if missing (Sanitary: 0.4m, Appliances/Furnishing: 0.8m)
        h = dims[2] if len(dims) > 2 else (0.4 if item.category == "sanitary" else 0.8)

        if item.category == "sanitary":
            ifc_ent = model.create_entity("IfcSanitaryTerminal", GlobalId=ifcopenshell.guid.new(), Name=item.id, ObjectPlacement=item_loc)
            pset_key = "Pset_SanitaryTerminalTypeCommon"
        elif item.category == "appliance":
            ifc_ent = model.create_entity("IfcElectricAppliance", GlobalId=ifcopenshell.guid.new(), Name=item.id, ObjectPlacement=item_loc)
            pset_key = "Pset_ElectricApplianceTypeCommon"
        else:
            ifc_ent = model.create_entity("IfcFurnishingElement", GlobalId=ifcopenshell.guid.new(), Name=item.id, ObjectPlacement=item_loc)
            pset_key = "Pset_FurnitureTypeCommon"
        
        interior_overrides = {
            pset_key: {
                "OverallWidth": w,
                "OverallDepth": d,
                "OverallHeight": h
            }
        }
        assign_default_ifc_properties(model, owner_h, ifc_ent, ifc_ent.is_a(), props_module, custom_overrides=interior_overrides, debug=debug)
        
        f_pts = [model.create_entity("IfcCartesianPoint", Coordinates=c) for c in [(0.,0.), (w,0.), (w,d), (0.,d), (0.,0.)] ]
        f_profile = model.create_entity("IfcArbitraryClosedProfileDef", ProfileType="AREA", OuterCurve=model.create_entity("IfcPolyline", Points=f_pts))
        f_solid = model.create_entity("IfcExtrudedAreaSolid", SweptArea=f_profile, Position=world_pl, ExtrudedDirection=model.create_entity("IfcDirection", DirectionRatios=(0.,0.,1.)), Depth=h)
        ifc_ent.Representation = model.create_entity("IfcProductDefinitionShape", Representations=[model.create_entity("IfcShapeRepresentation", ContextOfItems=context, RepresentationIdentifier="Body", RepresentationType="SweptSolid", Items=[f_solid])])
        elements.append(ifc_ent)

    model.create_entity("IfcRelContainedInSpatialStructure", GlobalId=ifcopenshell.guid.new(), RelatingStructure=storey, RelatedElements=elements)
    model.write(output_filepath)
    print(f"[Success] Fully Detailed & Connected BIM Generated: {output_filepath}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", default="1 BHK HOUSE .jpg")
    parser.add_argument("--output", default="1_BHK_Detailed.ifc")
    parser.add_argument("--cache", default="1_BHK_Detailed_Cache.json")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--debug", action="store_true", help="Print debug logs for IFC property attachments")
    args = parser.parse_args()

    if os.path.exists(args.cache) and not args.force:
        with open(args.cache, 'r') as f:
            data = BuildingAnalysis(**json.load(f))
    else:
        data = analyze_floor_plan_detailed(args.image)
        with open(args.cache, 'w') as f:
            json.dump(data.model_dump(), f, indent=4)

    prop_paths = find_ifc_properties_files()
    print(f"[Info] Found {len(prop_paths)} ifc_properties.py file(s): {prop_paths}")
    if not prop_paths:
        sys.exit("[Error] No ifc_properties.py found in the search path.")

    ifc_props = load_ifc_properties_module(prop_paths[0])
    build_detailed_ifc(data, args.output, props_module=ifc_props, debug=args.debug)
